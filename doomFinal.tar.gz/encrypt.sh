#!/bin/bash
clear
ls -a
echo ""
echo "Generating keys"
rm -f key
./keyGen key
sleep 1
echo "One-time key generated"
echo ""
read -p "Which file do you want to encypher?  " source
read -p "What will the cyphered file be named?  " output
echo ""
echo "Applying cypher ..."
rm -f $output
./encrypt key $source $output
sleep 1
echo "Deleting source file ..."
sleep 1
echo "Destroying key ..."
sleep 1
rm key
rm $source
echo ""
echo "Cypher application                OK"
echo "Key and Source destruction        OK"
echo "Cypher file creation              OK"
echo ""
echo "Use vim $output to see the encyphered file"
echo ""
