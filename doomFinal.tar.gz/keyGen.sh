#!/bin/bash
clear
echo "Generating keys"
./keyGen key
sleep 1
echo "Keys created"
