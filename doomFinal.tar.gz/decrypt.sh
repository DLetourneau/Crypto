#!/bin/bash
clear
ls
echo ""
read -p "Which file do you want to decypher?  " cypher
read -p "What will the decyphered file be named?  " cleartext
echo ""
echo "Reading $cypher ..."
rm -f $cleartext
./decrypt $cypher $cleartext
sleep 1
echo "Decyphering ..."
rm -f $cypher
sleep 1
echo ""
echo "Cyphered file destruction  OK"
echo "Clear text file status     OK"
echo ""
echo "Use: vim $cleartext to see the decyphered text"
echo ""
