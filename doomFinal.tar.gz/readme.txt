Project coded by Dom Letourneau
From August to Septembre 2016
As part of a final project at CDE College
Written in C and compiled using GCC on a Ubuntu Xenial system
Code is available online:
	https://github.com/dletourneau/crypto

Standard convention was used to name the files.
There are hidden "safe" copies of the sample textfiles (.sample.ori).
All the source, header and shell files are hidden.
The source file must be recompiled to use on another system.

**************************************************************************
 				WARNING

 THIS IS NOT MEANT TO BE A SECURE TOOL TO ENCRYPT INFORMATION, THE CYPHER
 USED IS SOMEWHAT SIMPLE AND THE CODE IS PUBLICLY AVAILABLE.

**************************************************************************

Usage:

To generate a key: bash .keyGen.sh -> will output "key"
To encrypt manually: ./encrypt keyfile sourcefile outfile
To decrypt manually: ./decrypt cryptfile clearfile
To encrypt automatically: bash .encrypt.sh 
	-> will prompt for source and outfile
To decrypt automatically: bash .decrypt.sh
	-> will prompt for crypted and outfile
To compile: bash .make.sh
	-> will prompt for sourcefile and executable

File List:

.yates.c	: Key generator using a Yates Shuffle
.decrypt.c	: Decyphering too
.encrypt.c	: Cyphering tool
.persolib.h	: Personal library, contains all functions and libs used
		  in the source files
.make.sh	: Shell to compile the source files
.keyGen.sh	: Shell to run the key generator
.encrypt.sh	: Shell to run the encryption (runs both keyGen and encrypt)
.decrypt.sh	: Shell to run the decryption
key		: Default output file when .keyGen.sh is called
keyGen		: Key Generator executable
encrypt		: Cyphering tool executable
decrypt		: Decyphering tool executable
license.txt	: The distribution license for this software
readme.txt	: This file
